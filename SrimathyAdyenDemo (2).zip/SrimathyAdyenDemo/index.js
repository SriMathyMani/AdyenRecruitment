const express = require("express");
const path = require("path");
const hbs = require("express-handlebars");
const dotenv = require("dotenv");
const morgan = require("morgan");
const { uuid } = require("uuidv4");
const { Client, Config, CheckoutAPI } = require("@adyen/api-library");
const app = express();

// Set up request logging
app.use(morgan("dev"));
// Parse JSON bodies
app.use(express.json());
// Parse URL-encoded bodies
app.use(express.urlencoded({ extended: true }));
// Serve client from build folder
app.use(express.static(path.join(__dirname, "/public")));

// Enables environment variables by parsing the .env file and assigning it to process.env
dotenv.config({
  path: "./.env",
});

// Adyen Node.js API library boilerplate (configuration, etc.)
const config = new Config();
config.apiKey = "AQEyhmfxKonIYxZGw0m/n3Q5qf3VaY9UCJ14XWZE03G/k2NFikzVGEiYj+4vtN01BchqAcwQwV1bDb7kfNy1WIxIIkxgBw==-JtQ5H0iXtu8rqQMD6iAb33gf2qZeGKGhrMpyQAt9zsw=-3wAkV)*$kP%bCcSf";//process.env.API_KEY;
const client = new Client({ config });
client.setEnvironment("TEST");
const checkout = new CheckoutAPI(client);

app.engine(
  "handlebars",
  hbs({
    defaultLayout: "main",
    layoutsDir: __dirname + "/views/layouts",
    partialsDir: __dirname + "/views/partials",
  })
);

app.set("view engine", "handlebars");

const paymentDataStore = {};

// Get payment methods
app.get("/", async (req, res) => {
  try {
	 
    const response = await checkout.paymentMethods({
      channel: "Web",
      merchantAccount: "AdyenRecruitmentCOM",//process.env.MERCHANT_ACCOUNT,
    });
	
    res.render("payment", {
      clientKey: "test_7ZCG2HRVQ5DYDG54CTVFVXKYFIKWXTBF",//process.env.CLIENT_KEY,
      response: JSON.stringify(response),
    });
  } catch (err) {
	console.log("test");
    console.error(`Error: ${err.message}, error code: ${err.errorCode}`);
    res.status(err.statusCode).json(err.message);
  }
});

app.post("/api/initiatePayment", async (req, res) => {
	
  // find shopper IP from request
  const shopperIP = req.headers["x-forwarded-for"] || req.connection.remoteAddress;

  console.log(shopperIP);
  
  try {
	 
    const orderRef = uuid()+"srimathy_checkoutChallenge";
	console.log("Reference i created:" +orderRef);
	
	
    const response = await checkout.payments({
		
      amount: { currency: "EUR", value: 1000 }, 
      reference: orderRef,
      merchantAccount: "AdyenRecruitmentCOM",//process.env.MERCHANT_ACCOUNT,
      channel: "Web",
      additionalData: {
        allow3DS2: true,
      },
	  origin:"http://localhost:8080",
      returnUrl: `http://localhost:8080/api/handleShopperRedirect?orderRef=${orderRef}`,
      browserInfo: req.body.browserInfo,
	  paymentMethod: {
        type: "scheme",
        encryptedCardNumber: req.body.paymentMethod.encryptedCardNumber,
        encryptedExpiryMonth: req.body.paymentMethod.encryptedExpiryMonth,
        encryptedExpiryYear: req.body.paymentMethod.encryptedExpiryYear,
        encryptedSecurityCode: req.body.paymentMethod.encryptedSecurityCode,
        holderName: req.body.paymentMethod.holderName
  },
     paymentMethod: req.body.paymentMethod,
	  reference: orderRef,
      shopperEmail: "srimathydesktop@gmail.com",
	  });

    let resultCode = response.resultCode;
	let action = null;
	
    if (response.action) {
      action = response.action;
		  paymentDataStore[orderRef] = action.paymentData;
    }

    res.json({ resultCode, action });
  } catch (err) {
    console.error(`Error: ${err.message}, error code: ${err.errorCode}`);
    res.status(err.statusCode).json(err.message);
  }
});

app.all("/api/handleShopperRedirect", async (req, res) => {
  // Create the payload for submitting payment details
  const redirect = req.method === "GET" ? req.query : req.body;
  const details = {};
  if (redirect.redirectResult) {
    details.redirectResult = redirect.redirectResult;
  } else if (redirect.payload) {
    details.payload = redirect.payload;
  }

  try {
    const response = await checkout.paymentsDetails({ details });
    // Conditionally handle different result codes for the shopper
    switch (response.resultCode) {
      case "Authorised":
	  console.log("I am coming inside");
        res.redirect("/success");
        break;
      case "Pending":
      case "Received":
        res.redirect("/pending");
        break;
      case "Refused":
        res.redirect("/failed");
        break;
      default:
        res.redirect("/error");
        break;
    }
  } catch (err) {
    console.error(`Error: ${err.message}, error code: ${err.errorCode}`);
    res.redirect("/result/error");
  }
});

// Handle submitting additional details
app.post("/api/submitAdditionalDetails", async (req, res) => {
  // Create the payload for submitting payment details
  const payload = {};
  payload["details"] = req.body.details;
  payload["paymentData"] = req.body.paymentData;

  try {
    // Return the response back to client (for further action handling or presenting result to shopper)
    const response = await checkout.paymentsDetails(payload);
    let resultCode = response.resultCode;
    let action = response.action || null;

    res.json({ action, resultCode });
  } catch (err) {
    console.error(`Error: ${err.message}, error code: ${err.errorCode}`);
    res.status(err.statusCode).json(err.message);
  }
});

// Authorised result page
app.get("/success", (req, res) => res.render("success"));

// Pending result page
app.get("/pending", (req, res) => res.render("pending"));

// Error result page
app.get("/error", (req, res) => res.render("error"));

// Refused result page
app.get("/failed", (req, res) => res.render("failed"));

// Start server
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
